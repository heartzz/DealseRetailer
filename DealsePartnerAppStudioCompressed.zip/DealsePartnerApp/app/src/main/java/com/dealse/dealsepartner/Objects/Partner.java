package com.dealse.dealsepartner.Objects;

import java.io.Serializable;


/**
 * Created by harshank on 25/5/17.
 */

public class Partner implements Serializable {
    private String id;
    private String storeName;
    private String firstname;
    private String lastname;
    private String ownermobileNumber;
    private String storecontactNumber;
    private String emaiId;
    private String address;
    private String city;
    private String country;
    private String storeLatitude;
    private String storeLongitude;


    public Partner(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getOwnermobileNumber() {
        return ownermobileNumber;
    }

    public void setOwnermobileNumber(String ownermobileNumber) {
        this.ownermobileNumber = ownermobileNumber;
    }

    public String getStorecontactNumber() {
        return storecontactNumber;
    }

    public void setStorecontactNumber(String storecontactNumber) {
        this.storecontactNumber = storecontactNumber;
    }

    public String getEmaiId() {
        return emaiId;
    }

    public void setEmaiId(String emaiId) {
        this.emaiId = emaiId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getStoreLatitude() {
        return storeLatitude;
    }

    public void setStoreLatitude(String storeLatitude) {
        this.storeLatitude = storeLatitude;
    }

    public String getStoreLongitude() {
        return storeLongitude;
    }

    public void setStoreLongitude(String storeLongitude) {
        this.storeLongitude = storeLongitude;
    }
}
