package com.dealse.dealsepartner.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.darsh.multipleimageselect.activities.AlbumSelectActivity;
import com.darsh.multipleimageselect.helpers.Constants;
import com.darsh.multipleimageselect.models.Image;
import com.dealse.dealsepartner.Activities.Createofferscreen;
import com.dealse.dealsepartner.Objects.SelectedImages;
import com.dealse.dealsepartner.R;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Step2BannerImageFragment extends Fragment {

    RecyclerView imagesListView;
    public ArrayList<SelectedImages> selectedImagesList;
    SelectedDocImageAdapter selectedImageAdapter;
    public static Fragment newInstance() {
        return new Step2BannerImageFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View v = inflater.inflate(R.layout.step2bannerimagefragment, null, false);

        imagesListView = (RecyclerView)v.findViewById(R.id.recyclerView);

        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        imagesListView.setHasFixedSize(true);
        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(getActivity(),2);
        imagesListView.setLayoutManager(mLayoutManager);



        selectedImagesList = new ArrayList<SelectedImages>();

        SelectedImages si = new SelectedImages();
        si.path = "last";
        selectedImagesList.add(si);
        selectedImageAdapter = new SelectedDocImageAdapter(getActivity(),selectedImagesList);
        imagesListView.setAdapter(selectedImageAdapter);


        return v;
    }

    public void startPicker(){
        Intent intent = new Intent(getActivity(), AlbumSelectActivity.class);
        //set limit on number of images that can be selected, default is 10
        intent.putExtra(Constants.INTENT_EXTRA_LIMIT, 10);
        startActivityForResult(intent,Constants.REQUEST_CODE);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == Constants.REQUEST_CODE && resultCode == getActivity().RESULT_OK && data != null) {
            //The array list has the image paths of the selected images
            ArrayList<Image> images = data.getParcelableArrayListExtra(Constants.INTENT_EXTRA_IMAGES);
            Log.d("Got it", images.get(0).toString());

            selectedImagesList = new ArrayList<SelectedImages>();

            for (int i = 0; i < images.size(); i++) {
                SelectedImages si = new SelectedImages();
                si.path = images.get(i).path;
                selectedImagesList.add(si);
            }

            SelectedImages si = new SelectedImages();
            si.path = "last";
            selectedImagesList.add(si);

            imagesListView.setVisibility(View.VISIBLE);
            selectedImageAdapter = new SelectedDocImageAdapter(getActivity(),selectedImagesList);
            imagesListView.setAdapter(selectedImageAdapter);

        }
    }


    public class SelectedDocImageAdapter extends RecyclerView.Adapter<SelectedDocImageAdapter.MyViewHolder> {


        private Context a;
        private List<SelectedImages> selectedImagesList;
        public SelectedDocImageAdapter(Activity a, List<SelectedImages> selectedImagesList) {
            this.a = a;
            this.selectedImagesList = selectedImagesList;
        }
        @Override
        public SelectedDocImageAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.selectedimageitem, parent, false);

            return new SelectedDocImageAdapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(final SelectedDocImageAdapter.MyViewHolder holder, final int position) {


            if(selectedImagesList.get(position).path.equalsIgnoreCase("last")){
                holder.removeicn.setVisibility(View.GONE);
                holder.progressBar.setVisibility(View.GONE);
                holder.image.setVisibility(View.GONE);
                holder.plustxt.setVisibility(View.VISIBLE);
                holder.addtxt.setVisibility(View.VISIBLE);

                holder.plustxt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startPicker();
                    }
                });
            }else if(selectedImagesList.get(position).imgDrawable > 0){

                holder.plustxt.setVisibility(View.GONE);
                holder.addtxt.setVisibility(View.GONE);

                Picasso.with(a)
                        .load(selectedImagesList.get(position).imgDrawable)
                        //       .fit()
                        .skipMemoryCache()
                        .into(holder.image, new Callback() {
                            @Override
                            public void onSuccess() {
                                holder.progressBar.setVisibility(View.GONE);
                            }

                            @Override
                            public void onError() {

                            }
                        });

            }else {

                holder.plustxt.setVisibility(View.GONE);
                holder.addtxt.setVisibility(View.GONE);

                File imgFile = new File(selectedImagesList.get(position).path);

                Picasso.with(a)
                        .load(imgFile)
                        //       .fit()
                        .skipMemoryCache()
                        .into(holder.image, new Callback() {
                            @Override
                            public void onSuccess() {
                                holder.progressBar.setVisibility(View.GONE);
                            }

                            @Override
                            public void onError() {

                            }
                        });

            }

            holder.removeicn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    selectedImagesList.remove(position);
                    notifyDataSetChanged();
                }
            });
        }

        @Override
        public int getItemCount() {
            return selectedImagesList.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {



            ImageView image;
            ImageView removeicn;
            ProgressBar progressBar;
            TextView plustxt,addtxt;

            public MyViewHolder(View view) {
                super(view);
                image = (ImageView)view.findViewById(R.id.image);
                removeicn = (ImageView)view.findViewById(R.id.removeicn);
                progressBar = (ProgressBar) view.findViewById(R.id.progressBar);
                plustxt = (TextView) view.findViewById(R.id.plustxt);
                addtxt = (TextView) view.findViewById(R.id.addtxt);
            }
        }
    }

}