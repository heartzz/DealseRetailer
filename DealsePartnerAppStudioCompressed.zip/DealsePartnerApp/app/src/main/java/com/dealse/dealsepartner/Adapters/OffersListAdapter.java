package com.dealse.dealsepartner.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.dealse.dealsepartner.Objects.Deals;
import com.dealse.dealsepartner.R;

import java.util.List;

public class OffersListAdapter extends RecyclerView.Adapter<OffersListAdapter.MyViewHolder> {


    private Context a;
    private List<Deals> createddealsList;

    public OffersListAdapter(Context a, List<Deals> createddealsList) {
        this.a = a;
        this.createddealsList = createddealsList;
    }

    @Override
    public OffersListAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.offerlistitem, parent, false);

        return new OffersListAdapter.MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final OffersListAdapter.MyViewHolder holder, final int position) {

        holder.oferidtxt.setText("123456"+createddealsList.get(position).dealId);
    }

    @Override
    public int getItemCount() {
        return createddealsList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView offerImage;
        TextView oferidtxt,offertext,fromtodates;



        public MyViewHolder(View view) {
            super(view);

            offerImage = (ImageView)view.findViewById(R.id.itemImage1);
            oferidtxt = (TextView)view.findViewById(R.id.oferidtxt);
            offertext = (TextView)view.findViewById(R.id.offertext);
            fromtodates = (TextView)view.findViewById(R.id.fromtodates);

        }
    }
}