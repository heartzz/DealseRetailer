package com.dealse.dealsepartner.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.dealse.dealsepartner.Adapters.OffersListAdapter;
import com.dealse.dealsepartner.Objects.Deals;
import com.dealse.dealsepartner.R;

import java.util.ArrayList;
import java.util.List;

public class ManageOffersScreen extends AppCompatActivity {

    private Toolbar mToolbar;
    RecyclerView recyclerView;
    OffersListAdapter offersListAdapter;
    private List<Deals> createddealsList;
    FloatingActionButton fab;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.manageoffers);
        initToolbar();


        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);

        fab = (FloatingActionButton)findViewById(R.id.fab);

        LinearLayoutManager llm = new LinearLayoutManager(ManageOffersScreen.this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(llm);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setNestedScrollingEnabled(false);


        createddealsList = new ArrayList<>();

                Deals deals;
                deals = new Deals();
                deals.dealId = "78901";
                createddealsList.add(deals);

                deals = new Deals();
                deals.dealId = "7";
                createddealsList.add(deals);

                deals = new Deals();
                deals.dealId = "78";
                createddealsList.add(deals);

                deals = new Deals();
                deals.dealId = "901";
                createddealsList.add(deals);

                offersListAdapter = new OffersListAdapter(ManageOffersScreen.this, createddealsList);
                recyclerView.setAdapter(offersListAdapter);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent createofferIntent = new Intent(ManageOffersScreen.this,CreateNewOfferStepper.class);
                startActivity(createofferIntent);

            }
        });


    }

    private void initToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        ImageView toolbar_back = (ImageView) findViewById(R.id.toolbar_back);
        getSupportActionBar().setTitle(null);
        //toolbar_title.setTypeface(GetFonts.getInstance().getRobotoFont(TravFeddHomeScreen.this));
        toolbar_title.setText("Manage Offers");
        toolbar_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
}
