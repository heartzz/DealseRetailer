package com.dealse.dealsepartner.Activities;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.dealse.dealsepartner.Objects.Partner;
import com.dealse.dealsepartner.R;

import java.util.Calendar;

/**
 * Created by Harshank Sananse on 12/2/2016.
 */
public class Merchant_signup extends AppCompatActivity {

    private Toolbar mToolbar;
    private ScrollView parentactionscroll;
    private RelativeLayout relativeLayout;
    private EditText businesset,firstnameet,lastnameet,phoneet,emailet,storecontactet,addressrt,cityet,countryet;
    private RelativeLayout relativeLayoutcountry;
    private RelativeLayout relativeLayoutpassword;
    private EditText genderet;
    private Button btnRegister;
    private Button button;
    private View dottedView;
    private RelativeLayout relativeLayoutp;
    private RelativeLayout relativeLayoutpp;
    private EditText dateofbirthet;
    private TextView textView;
    private TextView textView2;
    //private List<AddUserResponse> addUserResponsesList;
    //private List<AddUserResponse> addUserResponses;

    public String businessetString,firstnameetString,lastnameetString,phoneetString,emailetString,storecontactetString,addressrtString,cityetSting,countryetSting;

    public static  Partner partnerDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.merchant_signup_screen);
        initToolbar();
        btnRegister = (Button)findViewById(R.id.btnRegister);
        findViews();




        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                businessetString = businesset.getText().toString();
                firstnameetString = firstnameet.getText().toString();
                lastnameetString = lastnameet.getText().toString();
                phoneetString = phoneet.getText().toString();
                emailetString = emailet.getText().toString();
                storecontactetString = storecontactet.getText().toString();
                addressrtString = addressrt.getText().toString();
                cityetSting = cityet.getText().toString();
                countryetSting = countryet.getText().toString();

                if(!businessetString.equalsIgnoreCase("") && !firstnameetString.equalsIgnoreCase("") && !lastnameetString.equalsIgnoreCase("")
                        && !phoneetString.equalsIgnoreCase("")
                        && !emailetString.equalsIgnoreCase("")
                        && !storecontactetString.equalsIgnoreCase("")
                        && !addressrtString.equalsIgnoreCase("")
                        && !cityetSting.equalsIgnoreCase("")){

                    partnerDetails = new Partner();
                    partnerDetails.setStoreName(businessetString);
                    partnerDetails.setFirstname(firstnameetString);
                    partnerDetails.setLastname(lastnameetString);
                    partnerDetails.setOwnermobileNumber(phoneetString);
                    partnerDetails.setEmaiId(emailetString);
                    partnerDetails.setStorecontactNumber(storecontactetString);
                    partnerDetails.setAddress(addressrtString);
                    partnerDetails.setCity(cityetSting);
                    partnerDetails.setCountry(countryetSting);
               //     partnerDetails.setStoreLatitude();
               //     partnerDetails.setStoreLongitude();

                    Intent mainintent = new Intent(Merchant_signup.this, HomeScreen.class);
                    startActivity(mainintent);

                }else{
                    Toast.makeText(Merchant_signup.this,"Please enter all the fields", Toast.LENGTH_SHORT).show();
                }

            }
        });




    }

    private void findViews() {


        parentactionscroll = (ScrollView) findViewById(R.id.parentactionscroll);
        relativeLayout = (RelativeLayout) findViewById(R.id.relativeLayout);
        businesset = (EditText) findViewById(R.id.businesset);
        firstnameet = (EditText) findViewById(R.id.firstnameet);
        lastnameet = (EditText) findViewById(R.id.lastnameet);
        phoneet  = (EditText) findViewById(R.id.phoneet);
        emailet = (EditText) findViewById(R.id.emailet);
        storecontactet = (EditText) findViewById(R.id.storecontactet);
        addressrt = (EditText) findViewById(R.id.addressrt);
        cityet = (EditText) findViewById(R.id.cityet);
        countryet = (EditText) findViewById(R.id.countryet);

    }

    private void initToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        ImageView toolbar_back = (ImageView) findViewById(R.id.toolbar_back);
        getSupportActionBar().setTitle(null);
        //toolbar_title.setTypeface(GetFonts.getInstance().getRobotoFont(TravFeddHomeScreen.this));
        toolbar_title.setText(" ");
        toolbar_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }


    @SuppressLint("ValidFragment")
    public class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {

        int byear, bmonth, bday;

        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar calendar = Calendar.getInstance();
            byear = calendar.get(Calendar.YEAR);
            bmonth = calendar.get(Calendar.MONTH);
            bday = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog dpd = new DatePickerDialog(Merchant_signup.this,
                    AlertDialog.THEME_DEVICE_DEFAULT_LIGHT, this, byear, bmonth, bday);

            // dpd.setTitle("Select Date"); // Uncomment this line to activate it

            // Return the DatePickerDialog
            return new DatePickerDialog(getActivity(), this, byear, bmonth, bday);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            // Do something with the chosen date
            String date = day + "/" + (month + 1) + "/" + year;

            dateofbirthet.setText(date);
        }
    }
}
