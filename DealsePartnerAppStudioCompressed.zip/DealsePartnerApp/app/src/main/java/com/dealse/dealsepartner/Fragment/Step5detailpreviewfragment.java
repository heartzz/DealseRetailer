package com.dealse.dealsepartner.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dealse.dealsepartner.R;

public class Step5detailpreviewfragment extends Fragment {


    public static Fragment newInstance() {
        return new Step5detailpreviewfragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View v = inflater.inflate(R.layout.step5detailpreviewfragment, null, false);

        return v;
    }

}