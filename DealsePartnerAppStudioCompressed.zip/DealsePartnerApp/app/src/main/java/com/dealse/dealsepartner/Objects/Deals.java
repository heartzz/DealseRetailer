package com.dealse.dealsepartner.Objects;

/**
 * Created by harshank on 19/6/18.
 */

public class Deals {

    public String dealId;
    public String storeName;
    public String OfferName;
    public String OfferDescription;
    public String OfferImage;
    public String closingTime;
    public String itemsCount;
    public String storeDistance;
    public String offerStatus;

}
