package com.dealse.dealsepartner.Utility;

import android.text.TextUtils;

/**
 * Created by Harshank Sananse on 1/31/2017.
 */
public class UrlConstants {
    public static String BASE_URL = "http://192.168.2.100:45459/";

    public static boolean isEmpty(CharSequence str) {
        return TextUtils.isEmpty(str) || str.toString().equals("null");
    }
}
