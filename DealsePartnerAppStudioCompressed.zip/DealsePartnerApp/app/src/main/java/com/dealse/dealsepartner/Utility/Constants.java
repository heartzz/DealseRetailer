package com.dealse.dealsepartner.Utility;

/**
 * Created by harshank on 25/6/18.
 */

public class Constants {

    public static String VALUE_FIRSTAPPKEY = "4B16179D2F14DB157AD9587DBB138";
    public static String KEY_STOREID = "";
    public static String KEY_TOKEN = "token";
    public static String KEY_USERNAME = "username";
}
