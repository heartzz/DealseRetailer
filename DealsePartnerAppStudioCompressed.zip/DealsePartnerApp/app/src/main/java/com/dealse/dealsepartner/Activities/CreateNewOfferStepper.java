package com.dealse.dealsepartner.Activities;

import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.dealse.dealsepartner.Fragment.Step1DetailsFragment;
import com.dealse.dealsepartner.Fragment.Step2BannerImageFragment;
import com.dealse.dealsepartner.Fragment.Step3AllImagesFragment;
import com.dealse.dealsepartner.Fragment.Step4cardpreviewfragment;
import com.dealse.dealsepartner.Fragment.Step5detailpreviewfragment;
import com.dealse.dealsepartner.R;
import com.dealse.dealsepartner.Utility.ViewAnimation;

import java.util.Stack;

public class CreateNewOfferStepper extends AppCompatActivity {

    private static final int MAX_STEP = 5;
    private int current_step = 1;
    private TextView status;
    private Toolbar mToolbar;
    TextView newxtbtntv;
    Step1DetailsFragment step1DetailsFragment;
    Step2BannerImageFragment step2BannerImageFragment;
    Step3AllImagesFragment step3AllImagesFragment;
    Step4cardpreviewfragment step4cardpreviewfragment;
    Step5detailpreviewfragment step5detailpreviewfragment;
    FragmentManager fragmentManager;
    private Stack<Fragment> fragmentStack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.createofferstepper);

        initToolbar();
        initComponent();



        step1Fragment();
    }

    public void step1Fragment()
    {
        fragmentManager = getSupportFragmentManager();
        fragmentStack = new Stack<Fragment>();
        step1DetailsFragment = new Step1DetailsFragment();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        ft.add(R.id.container, step1DetailsFragment);
        fragmentStack.push(step1DetailsFragment);
        ft.commit();

    }

    public void step2Fragment()
    {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.anim.slide_in_left,R.anim.slide_in_right);
        step2BannerImageFragment = new Step2BannerImageFragment();
        ft.add(R.id.container,step2BannerImageFragment);
        fragmentStack.lastElement().onPause();
        ft.remove(fragmentStack.pop());
        fragmentStack.push(step2BannerImageFragment);
        ft.commit();
    }

    public void step3Fragment()
    {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.anim.slide_in_left,R.anim.slide_in_right);
        step3AllImagesFragment = new Step3AllImagesFragment();
        ft.add(R.id.container,step3AllImagesFragment);
        fragmentStack.lastElement().onPause();
        ft.remove(fragmentStack.pop());
        fragmentStack.push(step3AllImagesFragment);
        ft.commit();
    }

    public void step4Fragment()
    {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.anim.slide_in_left,R.anim.slide_in_right);
        step4cardpreviewfragment = new Step4cardpreviewfragment();
        ft.add(R.id.container,step4cardpreviewfragment);
        fragmentStack.lastElement().onPause();
        ft.remove(fragmentStack.pop());
        fragmentStack.push(step4cardpreviewfragment);
        ft.commit();
    }
    public void step5Fragment()
    {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction ft = fragmentManager.beginTransaction();
        //ft.setCustomAnimations(R.anim.slide_in_left,R.anim.slide_in_right);
        step5detailpreviewfragment = new Step5detailpreviewfragment();
        ft.add(R.id.container,step5detailpreviewfragment);
        fragmentStack.lastElement().onPause();
        ft.remove(fragmentStack.pop());
        fragmentStack.push(step5detailpreviewfragment);
        ft.commit();
    }



    private void initToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        TextView toolbar_title = (TextView) findViewById(R.id.toolbar_title);
        ImageView toolbar_back = (ImageView) findViewById(R.id.toolbar_back);
        getSupportActionBar().setTitle(null);
        //toolbar_title.setTypeface(GetFonts.getInstance().getRobotoFont(TravFeddHomeScreen.this));
        toolbar_title.setText("Create Offer");
        toolbar_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void initComponent() {
        status = (TextView) findViewById(R.id.status);
        newxtbtntv = (TextView) findViewById(R.id.newxtbtn);
        ((LinearLayout) findViewById(R.id.lyt_back)).setVisibility(View.INVISIBLE);
        ((LinearLayout) findViewById(R.id.lyt_back)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Back Prassed----------",current_step+"");
                if(current_step == 2){
                    ((LinearLayout) findViewById(R.id.lyt_back)).setVisibility(View.INVISIBLE);
                    step1Fragment();
                }else if(current_step == 3){
                    step2Fragment();
                }else if(current_step == 4){
                    step3Fragment();
                }else if(current_step == 5){
                    step4Fragment();
                }
                backStep(current_step);
                bottomProgressDots(current_step);
                newxtbtntv.setText("NEXT");
            }
        });

        ((LinearLayout) findViewById(R.id.lyt_next)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Next Prassed----------",current_step+"");
                ((LinearLayout) findViewById(R.id.lyt_back)).setVisibility(View.VISIBLE);

                    if(current_step == 1){
                        step2Fragment();
                    }else if(current_step == 2){
                        step3Fragment();
                    }else if(current_step == 3){
                        step4Fragment();
                    }else if(current_step == 4){
                        step5Fragment();
                        newxtbtntv.setText("DONE");
                    }else if(current_step == 5){

                    }
                    nextStep(current_step);
                    bottomProgressDots(current_step);
            }
        });

        String str_progress = String.format(getString(R.string.step_of), current_step, MAX_STEP);
        status.setText(str_progress);
        bottomProgressDots(current_step);
    }

    private void nextStep(int progress) {
        if (progress < MAX_STEP) {
            progress++;
            current_step = progress;
            ViewAnimation.fadeOutIn(status);
        }
        String str_progress = String.format(getString(R.string.step_of), current_step, MAX_STEP);
        //status.setText(str_progress);
    }

    private void backStep(int progress) {
        if (progress > 1) {
            progress--;
            current_step = progress;
            ViewAnimation.fadeOutIn(status);
        }
        String str_progress = String.format(getString(R.string.step_of), current_step, MAX_STEP);
        //status.setText(str_progress);
    }

    private void bottomProgressDots(int current_index) {
        current_index--;
        LinearLayout dotsLayout = (LinearLayout) findViewById(R.id.layoutDots);
        ImageView[] dots = new ImageView[MAX_STEP];

        dotsLayout.removeAllViews();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new ImageView(this);
            int width_height = 15;
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(new ViewGroup.LayoutParams(width_height, width_height));
            params.setMargins(10, 10, 10, 10);
            dots[i].setLayoutParams(params);
            dots[i].setImageResource(R.drawable.shape_circle);
            dots[i].setColorFilter(getResources().getColor(R.color.grey_20), PorterDuff.Mode.SRC_IN);
            dotsLayout.addView(dots[i]);
        }

        if (dots.length > 0) {
            dots[current_index].setImageResource(R.drawable.shape_circle);
            dots[current_index].setColorFilter(getResources().getColor(R.color.white), PorterDuff.Mode.SRC_IN);
        }
    }
}
