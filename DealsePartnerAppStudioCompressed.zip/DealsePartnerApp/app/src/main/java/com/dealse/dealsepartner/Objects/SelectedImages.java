package com.dealse.dealsepartner.Objects;

/**
 * Created by harshank on 13/6/18.
 */

public class SelectedImages {
    public String path = "";
    public String name;
    public String id;
    public int imgDrawable;
}